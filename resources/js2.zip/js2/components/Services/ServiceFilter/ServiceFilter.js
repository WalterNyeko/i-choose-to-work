import React from 'react'

const ServiceFilter = () => {
    return (
        <div>
            <h2>this is the filter</h2>
        </div>
    )
}

export default  ServiceFilter;
