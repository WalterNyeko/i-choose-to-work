import React, { Component } from 'react'

export default class ProtectedComponent extends Component {
  render() {
    return (
      <div>
        <h2>Hey am protected</h2>
      </div>
    )
  }
}
